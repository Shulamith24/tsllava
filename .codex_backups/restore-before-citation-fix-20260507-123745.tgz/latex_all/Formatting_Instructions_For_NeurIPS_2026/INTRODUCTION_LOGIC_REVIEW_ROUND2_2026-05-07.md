# Introduction Logic Review: TimeMorph

检查对象：`neurips_2026.tex` 的 Abstract 与 Introduction，重点关注 Introduction 的 NeurIPS 风格、行文逻辑、审稿风险、贡献表达和与后文 Method / Experiments 的一致性。

本轮只进行审阅与建议整理，未修改 `neurips_2026.tex` 或其他 LaTeX 正文文件。

## 1. 总体判断

当前 Introduction 的主线是成立的，整体已经接近 NeurIPS / ICML / ICLR 类机器学习论文的常见叙事方式。它不是简单罗列方法模块，而是围绕一个相对清楚的 thesis 展开：

> LLM-based few-shot TSC 的关键不只是把时间序列输入 LLM，而是设计一个合适的 time-series-to-language interface，使模型能够同时处理时间序列证据、连续特征到语言模型空间的对齐，以及闭集分类决策。

当前引言大致遵循以下链条：

1. TSC 重要，但标注稀缺，因此 few-shot TSC 有现实意义；
2. 时间序列判别证据可能同时体现为 temporal dynamics 与 waveform morphology；
3. LLM / foundation model 对 time-series adaptation 有吸引力，但直接用于 few-shot TSC 存在接口错配；
4. 这些错配引出三个设计目标：dual-view evidence、continuous-to-language alignment、closed-set prediction；
5. TimeMorph 对应提出 dual-view encoder、stage-wise transfer、class-token scoring；
6. 贡献与实验结论总结。

这条逻辑没有根本断裂，也基本符合 NeurIPS introduction 的写法。真正需要处理的是：当前版本写得有些“过满”和“过顺”，部分措辞把合理设计上升成较强的必要性判断，容易触发审稿人对 overclaim、fairness、novelty boundary 的追问。

建议优先做的不是推倒重写，而是四件事：

- 降低过强措辞，例如 `central bottleneck`、`decisive class signal`、`reusable pretrained sequence computation`、`left implicit`；
- 把 contribution 段和 empirical summary 拆开，降低结尾信息密度；
- 提前或更清楚地说明 fixed few-shot benchmark protocol 与 UCR unlabeled TRAIN pretraining 的边界；
- 去掉 Introduction 中两次相邻的 `(i)(ii)(iii)` 重复结构，让行文更自然。

## 2. 关于两次 `(i)(ii)(iii)` 的明确结论

你的直觉是对的：当前引言中连续两次使用 `(i)(ii)(iii)` 不算格式错误，但不太理想。

位置：

- `neurips_2026.tex:41`：三条 design desiderata；
- `neurips_2026.tex:45`：三条 main contributions。

问题不在于 NeurIPS 论文不能用 `(i)(ii)(iii)`。NeurIPS introduction 中列贡献很常见。问题在于这两组三点间隔太近，而且内容高度同构：

- desiderata 1：representations expose temporal dynamics and waveform morphology；
- contribution 1/2：interface design + dual-view encoder；
- desiderata 2：continuous features align with LLM input space；
- contribution 2：staged time-series-to-language pretraining；
- desiderata 3：prediction compare valid class candidates；
- contribution 3：class-token decision interface。

这种写法会让读者感觉“设计愿望 = 贡献列表”，有一点模板化，也会削弱叙事推进感。建议只保留一处显式枚举。更推荐保留 contribution 段的枚举，把 desiderata 段改成自然连续正文。

### 建议替换第 41 行段落

当前段落：

```latex
This perspective motivates three design desiderata for LLM-based few-shot TSC: (i) representations should expose both temporal dynamics and waveform morphology, since either form may carry the decisive class signal; (ii) continuous time-series features should be brought closer to the input space expected by the pretrained language model before downstream adaptation; and (iii) prediction should explicitly compare valid class candidates, rather than depending solely on unconstrained text generation \citep{raffel2020exploring,hokamp2017lexically,koo2024automata}. When these interface choices are left implicit, the language model may contribute limited task-specific discrimination despite adding substantial capacity.
```

建议替换为自然段：

```latex
These observations suggest that an effective LLM-based few-shot TSC interface should jointly address representation, alignment, and decision constraints. The representation should expose both temporal dynamics and waveform-level structure, because either form of evidence may be useful under scarce support examples. Continuous time-series tokens should be calibrated before they are used to condition a pretrained language model, reducing the burden placed on downstream few-shot adaptation. Prediction should also be restricted to valid class candidates rather than delegated to unconstrained text generation \citep{raffel2020exploring,hokamp2017lexically,koo2024automata}. When these issues are addressed separately or optimized for open-ended generation rather than closed-set few-shot classification, additional model capacity may not translate into reliable task-specific discrimination.
```

如果想更短，可以用：

```latex
These observations suggest that an effective interface should jointly address representation, alignment, and decision constraints: it should expose complementary temporal and waveform-level evidence, calibrate continuous time-series tokens before target adaptation, and restrict prediction to valid class candidates rather than unconstrained text generation \citep{raffel2020exploring,hokamp2017lexically,koo2024automata}. Otherwise, a larger language model may add capacity without providing reliable closed-set discrimination.
```

## 3. 最高优先级审稿风险

### 3.1 Few-shot 协议边界需要更早、更透明

相关位置：

- `neurips_2026.tex:35`
- `neurips_2026.tex:45`
- `neurips_2026.tex:297` 附近的实验设置
- `neurips_2026.tex:365` 附近的 limitations

当前第 1 段写道：

```latex
We focus on the full-label-space few-shot setting, where each target dataset provides only a few labeled support examples per class, but query examples must still be classified among all classes in that dataset.
```

这句话本身正确，但后文实验设置说明 Stage I 使用了 fixed 98-dataset UCR pool 的 unlabeled official TRAIN sequences。也就是说，对于部分 UCR target datasets，模型在预训练阶段可能见过无标签 TRAIN 序列。虽然没有使用 UCR TEST sequences，也没有使用 UCR class labels，这仍然不是严格的 leave-dataset-out transfer。

审稿风险在于：读者在 Introduction 中形成“每个 target dataset 只提供 few-shot support”的预期，到 Experiments 或 Limitations 才发现部分 UCR TRAIN sequences 被无标签预训练使用，可能会质疑协议透明度。

建议不要把这个写成自我削弱，而是主动定义为 label-scarce transfer / fixed few-shot benchmark protocol。

推荐替换第 1 段设定句：

```latex
We study a label-scarce full-label-space few-shot protocol: downstream adaptation uses only a few labeled support examples per class, while query examples must still be classified among all classes in the target dataset. In our default transfer setting, representation pretraining may use unlabeled training sequences but never uses target test sequences or class labels.
```

如果不想在第 1 段引入协议细节，至少在 Introduction 结尾结果句中补一句：

```latex
Our pretraining uses no UCR test sequences or UCR class labels, although Stage I may use unlabeled official TRAIN sequences from a fixed UCR dataset pool.
```

### 3.2 Abstract 的结果表述偏强，会影响 Introduction 可信度

相关位置：`neurips_2026.tex:31`

当前 Abstract 写道：

```latex
Extensive few-shot experiments on the UCR benchmark and additional external datasets show that TimeMorph consistently outperforms strong task-specific, Transformer-style, and LLM/foundation baselines.
```

这个表述比 Introduction 和 Experiments 的实际口径更强。主表显示 TimeMorph 在 macro-average accuracy 和 AvgRank 上最好，但 W/T/L 说明对 COSCO-ResNet 这类强 CNN/prototype baseline 不是逐数据集稳定胜出。Experiments 自己也承认：相对最强 CNN/prototype baselines 的优势是 modest。

建议替换为：

```latex
Extensive few-shot experiments on the UCR benchmark and additional external datasets show that TimeMorph achieves the best macro-averaged accuracy and average rank, with clear gains over Transformer-style and LLM-style baselines and more modest gains over strong task-specific CNN/prototype baselines.
```

更稳妥版本：

```latex
Extensive few-shot experiments on the UCR benchmark and additional external datasets show that TimeMorph achieves the best macro-averaged accuracy and average rank among the compared methods, with clear gains over Transformer-style and the evaluated LLM-style baseline and more modest gains over strong CNN/prototype baselines.
```

### 3.3 `prior LLM/foundation baselines` 覆盖范围略宽

相关位置：

- `neurips_2026.tex:45`
- `neurips_2026.tex:301`

Introduction 写道：

```latex
with the clearest gains over Transformer-style and prior LLM/foundation baselines
```

但主实验中的 LLM/foundation-style baseline 实际主要是 `GPT4TS`。Related Work 中提到 LLMFew、TEST、Time-LLM、LLM4TS、OpenTSLM，其中 LLMFew 还被写成 closest few-shot classification line。如果 Introduction 使用 `prior LLM/foundation baselines` 复数，审稿人可能追问为什么没有和这些更接近方法比较。

建议收窄为：

```latex
with the clearest gains over the evaluated Transformer-style baselines and the GPT4TS LLM-style baseline
```

或者：

```latex
with the clearest gains over the evaluated Transformer-style and LLM-style baselines
```

### 3.4 `central bottleneck` 证明负担较重

相关位置：`neurips_2026.tex:45`

当前贡献写道：

```latex
we identify interface design as a central bottleneck for LLM-based few-shot TSC
```

这个 framing 有价值，但 `central bottleneck` 证明负担比较重。后文 ablation 支撑了 dual-view、pretraining、class-token scoring 有用，但没有系统证明 interface design 比模型容量、预训练数据、LoRA、DINOv2 或其他因素更“中心”。此外，相关工作中 reprogramming、alignment、semantic anchors 也属于 interface design。

建议降调为：

```latex
we frame LLM-based few-shot TSC as an interface-design problem involving complementary time-series evidence, continuous-to-language alignment, and closed-set prediction
```

或：

```latex
we study three interface choices for LLM-based few-shot TSC: complementary evidence exposure, continuous-token alignment, and closed-set prediction
```

## 4. 段落级反馈

### 第 1 段：任务背景与 few-shot setting

相关位置：`neurips_2026.tex:35`

优点：开头自然，应用场景合适，也能把 few-shot 的现实原因讲清楚，包括 annotation cost、新类别和类别不均衡。`full-label-space few-shot setting` 提前出现是对的，因为它为后文 closed-set class-token scoring 提供了任务需求。

主要不足：这一段只说了“few-shot”，还没有把“闭集分类 + 协议边界”讲得足够明确。建议把最后一句收紧到 closed-set few-shot classification，并尽早暗示 target support 是唯一带标签的适配来源。

可替换文本：

```latex
Time series classification (TSC) is a fundamental problem in healthcare monitoring, industrial diagnosis, sensor analytics, and scientific discovery \citep{ismail2019deep}. In many practical scenarios, labeled time series are difficult to obtain: annotation often requires domain expertise, new categories may appear with only a few examples, and class distributions can be highly imbalanced. We study a label-scarce full-label-space few-shot setting, where downstream adaptation receives only a few labeled support examples per class, yet query examples must still be classified among all classes in the target dataset. A successful model must therefore reuse transferable sequence representations, adapt from only a small support set, and still make stable closed-set decisions over the target labels \citep{tang2020interpretable}.
```

### 第 2 段：temporal dynamics 与 waveform morphology

相关位置：`neurips_2026.tex:37`

优点：这是 Introduction 中最有价值的动机段之一。它把 temporal branch 和 morphology branch 的必要性从 TSC 任务结构中推导出来，而不是直接说“我们用了两个 encoder”。

主要不足：

- `temporal` 与 `morphology` 并不是天然互斥，peaks、valleys、motifs、subsequences 本身也发生在时间轴上；
- `shape-oriented`、`waveform morphology`、`morphological structure` 等术语略有漂移；
- morphology map + frozen vision encoder 更稳妥的表达是 two encodings / two inductive biases，而不是两种本体上完全分离的证据。

建议把二者写成“互补编码偏置”，不要写成两种天然互斥的证据类型：

```latex
A key challenge is that discriminative evidence in time series may be exposed by different, partially overlapping encodings. A temporal encoding preserves ordered dependencies in the original coordinate system, including local trends, amplitudes, phase shifts, and long-range evolution. A morphology-oriented encoding instead emphasizes waveform-level regularities, such as recurring peaks, valleys, cycles, motifs, or discriminative subsequences whose exact positions may vary across examples. This view is reflected across the TSC literature, from shapelet methods that search for discriminative subsequences to convolutional, kernel-based, imaging, and ensemble methods that expose complementary local, global, and shape-based structure \citep{ye2009time,dempster2020rocket,fawaz2020inceptiontime,wang2015encoding,lines2016hive}. Under few-shot supervision, relying on a single encoding can make the classifier sensitive to unstable support-set cues and cause it to miss complementary evidence needed to separate fine-grained classes.
```

更短版本也可以，重点是把“view”写成“encoding / inductive bias”，而不是本体上完全分离的两类信息：

```latex
Prior TSC methods have long shown that discriminative signals may appear either as temporally localized dynamics or as shape-level motifs that are robust to small temporal misalignments. In the few-shot regime, this distinction becomes especially important: a support set may contain too few examples to reveal both forms of evidence through a single representation. This motivates representations that expose chronological dynamics and waveform-level regularities as complementary views rather than forcing all evidence into one encoding.
```

### 第 3 段：LLM 的机会与错配

相关位置：`neurips_2026.tex:39`

优点：该段方向正确：现有 LLM-based TS 方法多围绕 forecasting、reconstruction 或 text generation，而 few-shot TSC 需要 closed-set discrimination。

主要不足：

- `reusable pretrained sequence computation` 容易被质疑，因为 LLM 的序列能力来自文本 token，不等于天然适配连续时间序列；
- 前文已经列了 reprogramming、embedding alignment、semantic anchors，后面再说 `interface choices are left implicit`，容易让人觉得在 strawman；
- `stage-wise transfer` 的必要性还没有在引言里被讲透。

推荐替换：

```latex
Recent work has adapted pretrained language models to time-series analysis through numerical serialization, reprogramming, embedding alignment, semantic anchors, and parameter-efficient tuning \citep{brown2020language,gruver2023large,zhou2023one,jin2024timellm,sun2023test,jin2024time,chang2025llm4ts,zhang2024large,jiang2024empowering}. For few-shot TSC, the appeal of this direction is not that a language model is inherently a time-series classifier, but that it offers a high-capacity pretrained autoregressive backbone and a token-level prediction interface that can, in principle, be adapted with limited labels. Direct adaptation, however, leaves several mismatches unresolved. Time-series observations are continuous and domain-specific rather than discrete linguistic tokens; the few-shot support set is too small to learn a reliable encoder-projector-language alignment from scratch; and open-ended generation is poorly matched to closed-set classification over dataset-specific labels. These mismatches suggest that the key problem is the design of the time-series-to-language interface rather than the mere use of a large pretrained decoder.
```

### 第 4 段：interface design desiderata

相关位置：`neurips_2026.tex:41`

优点：这是全文引言的结构枢纽。三个 desiderata 与方法中的三个模块对应得很好。

主要不足：它和 contribution list 高度重复。建议去掉显式 `(i)(ii)(iii)`，改成连续正文；否则前后两段会像在重复同一套三点清单。替换建议见第 2 节。

### 第 5 段：方法概述

相关位置：`neurips_2026.tex:43`

优点：方法组件介绍完整，基本按前一段三个 interface issues 的顺序展开。

主要不足：

- `dual-view LLM-based transfer framework` 可以更自然；
- `makes shape-level structure accessible` 略显断言式，可改成 `intended to expose` 或 `processed by`；
- semantic verbalizer 是 optional extension，不宜和核心模块放得过平。

推荐替换：

```latex
We propose \textbf{TimeMorph}, a dual-view transfer framework that adapts a pretrained causal LLM to few-shot TSC. Given an input sequence, TimeMorph constructs temporal tokens from overlapping one-dimensional patches and morphology tokens from an image-like waveform map processed by a frozen vision encoder. The resulting dual-view tokens are fused and projected into the LLM through staged transfer training, which calibrates the encoder-projector interface before target-dataset adaptation. For classification, TimeMorph introduces dataset-specific class tokens and performs one-pass scoring over the valid class-token set, converting the autoregressive output layer into a supervised closed-set decision rule. For datasets whose class names are semantically meaningful, an optional label-verbalizer prior initializes and regularizes the class-token rows while preserving the same single-token decision space.
```

### 第 6 段：贡献与实验结果

相关位置：`neurips_2026.tex:45`

优点：贡献点和 Method / Experiments 基本能对应起来。当前结果句已经比 Abstract 克制，尤其写了 `more modest average gains over strong CNN/prototype baselines`，这是好习惯。

主要不足：

- 整段太长，一段里同时放贡献、协议边界、UCR 结果和 external semantic-label 结果；
- `central bottleneck` 略强，容易被审稿人要求补更系统的证据；
- `prior LLM/foundation baselines` 覆盖范围略宽，最好收窄到实际比较对象；
- semantic-label extension 更像附加发现，建议明确为 optional / additional finding，而不是主 benchmark 的核心支柱。

建议拆成两段：

```latex
Our contributions are threefold. First, we frame LLM-based few-shot TSC as an interface-design problem involving complementary time-series evidence, continuous-to-language alignment, and closed-set prediction. Second, we introduce a dual-view encoder that combines temporal dynamics with waveform morphology and aligns fused continuous tokens to a pretrained causal LLM through staged time-series-to-language pretraining. Third, we propose a supervised class-token scoring interface that performs one-pass scoring over valid labels, with an optional semantic-prior extension for datasets with meaningful class names.

Under a fixed full-label-space few-shot protocol on all 128 UCR datasets, TimeMorph achieves the best macro-averaged accuracy and average rank among the compared methods across 1-, 2-, 5-, and 10-shot settings. The gains are clearest over the evaluated Transformer-style baselines and the GPT4TS LLM-style baseline, while improvements over the strongest CNN/prototype baseline are consistent in macro-average accuracy but modest. Our pretraining uses no UCR test sequences or UCR class labels, although Stage I may use unlabeled official TRAIN sequences from a fixed UCR dataset pool. Additional experiments on MIT-BIH and CinC2017 provide transfer checks and suggest that semantic label priors can improve the same class-token interface on average when reliable class names are available.
```

## 5. 推荐的一版完整 Introduction 草稿

下面是一版更稳妥的完整替换草稿。它尽量保留当前版本的主线，但进一步收紧 LLM 表述、实验边界和术语。注意：这是建议稿，不是已写入 `neurips_2026.tex` 的修改。

```latex
\section{Introduction}
Time series classification (TSC) is a fundamental problem in healthcare monitoring, industrial diagnosis, sensor analytics, and scientific discovery \citep{ismail2019deep}. In many practical scenarios, labeled time series are difficult to obtain: annotation often requires domain expertise, new categories may appear with only a few examples, and class distributions can be highly imbalanced. We study a label-scarce full-label-space few-shot setting, where downstream adaptation receives only a few labeled support examples per class, yet query examples must still be classified among all classes in the target dataset. A successful model must therefore reuse transferable sequence representations, adapt from only a small support set, and still make stable closed-set decisions over the target labels \citep{tang2020interpretable}.

A key challenge is that discriminative evidence in time series may be exposed by different, partially overlapping encodings. A temporal encoding preserves ordered dependencies in the original coordinate system, including local trends, amplitudes, phase shifts, and long-range evolution. A morphology-oriented encoding instead emphasizes waveform-level regularities, such as recurring peaks, valleys, cycles, motifs, or discriminative subsequences whose exact positions may vary across examples. This view is reflected across the TSC literature, from shapelet methods that search for discriminative subsequences to convolutional, kernel-based, imaging, and ensemble methods that expose complementary local, global, and shape-based structure \citep{ye2009time,dempster2020rocket,fawaz2020inceptiontime,wang2015encoding,lines2016hive}. Under few-shot supervision, relying on a single encoding can make the classifier sensitive to unstable support-set cues and cause it to miss complementary evidence needed to separate fine-grained classes.

Recent work has adapted pretrained language models to time-series analysis through numerical serialization, reprogramming, embedding alignment, semantic anchors, and parameter-efficient tuning \citep{brown2020language,gruver2023large,zhou2023one,jin2024timellm,sun2023test,jin2024time,chang2025llm4ts,zhang2024large,jiang2024empowering}. For few-shot TSC, the appeal of this direction is not that a language model is inherently a time-series classifier, but that it offers a high-capacity pretrained autoregressive backbone and a token-level prediction interface that can, in principle, be adapted with limited labels. Direct adaptation, however, leaves several mismatches unresolved. Time-series observations are continuous and domain-specific rather than discrete linguistic tokens; the few-shot support set is too small to learn a reliable encoder-projector-language alignment from scratch; and open-ended generation is poorly matched to closed-set classification over dataset-specific labels. These mismatches suggest that the key problem is the design of the time-series-to-language interface rather than the mere use of a large pretrained decoder.

These observations suggest that an effective LLM-based few-shot TSC interface should jointly address representation, alignment, and decision constraints. The representation should expose both temporal dynamics and waveform-level structure, because either form of evidence may be useful under scarce support examples. Continuous time-series tokens should be calibrated before they are used to condition a pretrained language model, reducing the burden placed on downstream few-shot adaptation. Prediction should also be restricted to valid class candidates rather than delegated to unconstrained text generation \citep{raffel2020exploring,hokamp2017lexically,koo2024automata}. When these issues are addressed separately or optimized for open-ended generation rather than closed-set few-shot classification, additional model capacity may not translate into reliable task-specific discrimination.

We propose \textbf{TimeMorph}, a dual-view transfer framework that adapts a pretrained causal LLM to few-shot TSC. Given an input sequence, TimeMorph constructs temporal tokens from overlapping one-dimensional patches and morphology tokens from an image-like waveform map processed by a frozen vision encoder. The resulting dual-view tokens are fused and projected into the LLM through staged transfer training, which calibrates the encoder-projector interface before target-dataset adaptation. For classification, TimeMorph introduces dataset-specific class tokens and performs one-pass scoring over the valid class-token set, converting the autoregressive output layer into a supervised closed-set decision rule. For datasets whose class names are semantically meaningful, an optional label-verbalizer prior initializes and regularizes the class-token rows while preserving the same single-token decision space.

Our contributions are threefold. First, we frame LLM-based few-shot TSC as an interface-design problem involving complementary time-series evidence, continuous-to-language alignment, and closed-set prediction. Second, we introduce a dual-view encoder that combines temporal dynamics with waveform morphology and aligns fused continuous tokens to a pretrained causal LLM through staged time-series-to-language pretraining. Third, we propose a supervised class-token scoring interface that performs one-pass scoring over valid labels, with an optional semantic-prior extension for datasets with meaningful class names.

Under a fixed full-label-space few-shot protocol on all 128 UCR datasets, TimeMorph achieves the best macro-averaged accuracy and average rank among the compared methods across 1-, 2-, 5-, and 10-shot settings. The gains are clearest over the evaluated Transformer-style baselines and the GPT4TS LLM-style baseline, while improvements over the strongest CNN/prototype baseline are consistent in macro-average accuracy but modest. Our pretraining uses no UCR test sequences or UCR class labels, although Stage I may use unlabeled official TRAIN sequences from a fixed UCR dataset pool. Additional experiments on MIT-BIH and CinC2017 provide transfer checks and suggest that semantic label priors can improve the same class-token interface on average when reliable class names are available.
```

## 6. 如果只做最小修改，建议改这几处

如果当前不想大幅重写 Introduction，可以只做以下最小修改。

### 最小修改 1：Abstract 结果句

把：

```latex
Extensive few-shot experiments on the UCR benchmark and additional external datasets show that TimeMorph consistently outperforms strong task-specific, Transformer-style, and LLM/foundation baselines.
```

改为：

```latex
Extensive few-shot experiments on the UCR benchmark and additional external datasets show that TimeMorph achieves the best macro-averaged accuracy and average rank, with clear gains over Transformer-style and LLM-style baselines and more modest gains over strong task-specific CNN/prototype baselines.
```

### 最小修改 2：第 41 行去掉显式 `(i)(ii)(iii)`

把 desiderata 段改成自然正文，避免和 contribution list 重复，也避免让 introduction 像两次重复同一套三点提纲。

### 最小修改 3：贡献 1 降调

把：

```latex
we identify interface design as a central bottleneck for LLM-based few-shot TSC
```

改为：

```latex
we frame LLM-based few-shot TSC as an interface-design problem
```

### 最小修改 4：LLM/foundation baseline 范围收窄

把：

```latex
with the clearest gains over Transformer-style and prior LLM/foundation baselines
```

改为：

```latex
with the clearest gains over the evaluated Transformer-style baselines and the GPT4TS LLM-style baseline
```

### 最小修改 5：UCR pretraining 边界补充清楚

在结果句附近加入：

```latex
Our pretraining uses no UCR test sequences or UCR class labels, although Stage I may use unlabeled official TRAIN sequences from a fixed UCR dataset pool.
```

### 最小修改 6：semantic prior 结果加 `on average`

把：

```latex
Additional semantic-label experiments suggest that label semantics can further improve the same class-token interface when reliable class names are available.
```

改为：

```latex
Additional semantic-label experiments suggest that label semantics can further improve the same class-token interface on average when reliable class names are available.
```

## 7. 术语统一建议

建议 Introduction 中固定使用以下主术语：

```latex
few-shot time series classification / few-shot TSC
full-label-space few-shot setting
label-scarce transfer protocol
temporal dynamics
waveform morphology
morphology map
time-series-to-language interface
staged time-series-to-language transfer
class-token scoring / class-token scoring interface
closed-set prediction
```

建议少用或谨慎使用：

```latex
shape-oriented
morphological structure
visual pseudo-image branch
generative label-token scoring
prior LLM/foundation baselines
central bottleneck
consistently outperforms
decisive class signal
reusable pretrained sequence computation
left implicit
```

说明：

- `shape-oriented`、`morphological structure`、`shape-level structure` 可以作为解释性词汇，但主术语建议固定为 `waveform morphology`；
- `visual pseudo-image branch` 在 Abstract 中容易显得不够学术，Introduction 中建议用 `morphology branch` 或 `morphology-map branch`；
- `prior LLM/foundation baselines` 容易被理解成比较了多个 LLM/foundation 方法，当前实验主要是 GPT4TS；
- `closed-set prediction` 是任务目标，`class-token scoring interface` 是实现方式，二者层级要区分。

## 8. 不建议在 Introduction 中过度承诺的内容

1. 不要承诺 TimeMorph 或 LLM-based TSC “universally dominates” 专门 CNN/prototype few-shot classifiers。实验显示相对 COSCO-ResNet 的宏平均提升较小，W/T/L 也不是统一领先。
2. 不要承诺 LLM 增益来自“语言知识”或“推理能力”。no-LLM ablation 不能分离 pretrained knowledge、模型容量、LoRA、token interface 等因素。
3. 不要把 morphology map 写成已经被证明能理解视觉语义。更稳妥的说法是 image-like waveform map / morphology-oriented encoding。
4. 不要把 semantic label prior 写成普遍有效。当前只在 MIT-BIH 和 CinC2017 的平均结果上提升，且个别 shot-level 效果不一致。
5. 不要声称严格 leave-dataset-out transfer。UCR Stage I 使用了固定 98 个 UCR 数据集的无标签 official TRAIN sequences。
6. 不要暗示临床或工业部署已准备好。效率部分显示 LLM 带来明显延迟和内存成本。

## 9. 最终建议

当前 Introduction 没有逻辑上的硬伤，也基本符合 NeurIPS 写法。它的问题更像成熟论文打磨阶段常见的问题：主线已经搭好，但需要减少重复包装、降低过强宣称、提前说明实验协议边界，并让每段承担更单一的功能。

最推荐的一轮修改路线是：

1. Abstract 结果句降调；
2. 第 41 行去掉 `(i)(ii)(iii)`，改成自然的 design principle 段；
3. 第 45 行拆成 contribution 段和 empirical summary 段；
4. 把 `central bottleneck` 改为更稳的 `interface-design problem`；
5. 把 `prior LLM/foundation baselines` 收窄为 `evaluated Transformer-style baselines and the GPT4TS LLM-style baseline`；
6. 在 Introduction 中主动说明 UCR unlabeled TRAIN pretraining 的边界。

这样修改后，引言会更像一篇审稿友好的 NeurIPS 投稿：既有清楚主线和贡献，又不会因为 overclaim 或协议边界不透明而给审稿人留下容易攻击的点。
